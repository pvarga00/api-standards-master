# api-standards

Note: These were blantantly forked from: [https://github.com/paypal/api-standards](https://github.com/paypal/api-standards)

The .MDs files herein detail a LOT of great content on APIs and standardization (talking/learning points)
